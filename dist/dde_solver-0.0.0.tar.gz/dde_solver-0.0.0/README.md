DDe solver for differential equations, currently in development.
